const res = {{"data"}}
console.log(res);